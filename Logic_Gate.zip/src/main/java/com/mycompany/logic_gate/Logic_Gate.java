package com.mycompany.logic_gate;
import java.util.Scanner;

/**
 *
 * @author JG-Soto
 */
public class Logic_Gate {
    static Scanner leer = new Scanner(System.in);
    
    public static void main(String[] args) {
        // Definir las entradas de la compuerta AND
        System.out.println("Input the 1st value");
        boolean input1 = leer.nextBoolean();
        System.out.println("Input the 2nd value");
        boolean input2 = leer.nextBoolean();

        // Calcular la salida de la compuerta AND
        boolean output = AND(input1, input2);

        // Mostrar el resultado
        System.out.println("Input 1: " + input1);
        System.out.println("Input 2: " + input2);
        System.out.println("Output (AND): " + output);
    }
    
    // Función que simula una compuerta lógica AND
    public static boolean AND(boolean input1, boolean input2) {
        return input1 && input2;
    }
}